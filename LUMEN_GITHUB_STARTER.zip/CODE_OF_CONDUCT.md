# Code of Conduct

We want project discussion to remain constructive, technical and useful.

Participants should:

- communicate respectfully
- criticize ideas rather than people
- document assumptions and evidence
- preserve attribution and provenance
- avoid harassment, threats and discriminatory conduct
- report security issues responsibly

Maintainers may remove contributions or participation that materially disrupt
the project or violate these expectations.
