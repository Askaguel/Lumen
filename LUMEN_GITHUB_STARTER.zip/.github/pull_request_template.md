## What changed?

## Why?

## Validation / tests

## Rights / license impact

- [ ] No third-party rights changed
- [ ] New third-party material is properly attributed
- [ ] No credentials or secrets are included
