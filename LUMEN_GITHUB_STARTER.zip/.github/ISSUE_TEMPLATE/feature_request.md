---
name: Feature request
about: Suggest a capability, compiler target or improvement
title: "[FEATURE] "
labels: enhancement
---

## Problem

## Proposed capability / change

## Why it matters

## Target ecosystems

- [ ] OpenAPI
- [ ] MCP
- [ ] A2A
- [ ] UCP
- [ ] AWS
- [ ] Google Cloud
- [ ] Other

## Rights / dependency impact
